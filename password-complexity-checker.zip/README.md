# Password Complexity Checker

A modern, real-time password complexity checker built with React, TypeScript, and Tailwind CSS. This application provides instant feedback on password strength and helps users create secure passwords that meet industry standards.

![Password Complexity Checker](https://img.shields.io/badge/Password-Complexity%20Checker-blue)
![React](https://img.shields.io/badge/React-18.x-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind%20CSS-3.x-blue)

## 🚀 Features

- **Real-time Password Analysis**: Instant feedback as users type their password
- **Visual Strength Indicator**: Color-coded progress bar showing password strength (Weak, Medium, Strong)
- **Detailed Requirements Checklist**: Clear indicators for each security requirement
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Modern UI**: Clean, professional interface with smooth animations
- **Screenshot Capability**: Built-in screenshot functionality for demonstration
- **Export Functionality**: Download complete application as ZIP file

## 🔒 Password Requirements

The application checks for the following security requirements:

- ✅ At least 8 characters long
- ✅ Contains uppercase letter (A-Z)
- ✅ Contains lowercase letter (a-z)
- ✅ Contains number (0-9)
- ✅ Contains special character (!@#$%^&*)
- ✅ No spaces allowed

## 🛠️ Technology Stack

### Frontend
- **React 18** - Modern React with hooks
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **Shadcn/ui** - Reusable component library
- **Lucide React** - Modern icon library
- **Wouter** - Lightweight routing
- **TanStack Query** - Data fetching and caching

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **Puppeteer** - Headless browser for screenshots
- **Archiver** - ZIP file creation
- **TypeScript** - Type-safe server code

### Build Tools
- **Vite** - Fast build tool and dev server
- **ESBuild** - JavaScript bundler
- **PostCSS** - CSS processing
- **Drizzle ORM** - Database toolkit

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/password-complexity-checker.git
cd password-complexity-checker
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5000`

## 🚀 Usage

1. **Enter Password**: Type your password in the input field
2. **Real-time Feedback**: Watch the strength indicator update in real-time
3. **Check Requirements**: View the requirements checklist to see which criteria are met
4. **Screenshot**: Click the "Screenshot" button to capture the current state
5. **Download**: Click the "Download Zip" button to get the complete application

## 📱 Screenshots

### Main Interface
The application features a clean, modern interface with:
- Floating label input field
- Real-time password strength indicator
- Visual requirements checklist
- Action buttons for screenshot and download

### Password Strength Levels
- **Weak** (0-49%): Red indicator
- **Medium** (50-84%): Orange indicator  
- **Strong** (85-100%): Green indicator

## 🏗️ Project Structure

```
password-complexity-checker/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utility functions
│   │   └── hooks/         # Custom React hooks
│   └── index.html         # HTML template
├── server/                # Backend Express server
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   └── storage.ts        # Data storage logic
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schema definitions
├── package.json          # Dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── vite.config.ts        # Vite build configuration
└── tailwind.config.ts    # Tailwind CSS configuration
```

## 🔧 Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run type-check` - Run TypeScript type checking

### Key Components

- **PasswordStrengthIndicator**: Visual progress bar component
- **RequirementItem**: Individual requirement checklist item
- **PasswordChecker**: Main application component

## 📝 API Endpoints

- `POST /api/screenshot` - Capture application screenshot
- `POST /api/download-zip` - Download complete application package

## 🔒 Security Features

- Client-side password validation (no passwords sent to server)
- Industry-standard password requirements
- Real-time feedback to encourage strong passwords
- No password storage or logging

## 🌟 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🙏 Acknowledgments

- Built with modern React and TypeScript
- Styled with Tailwind CSS and Shadcn/ui
- Icons provided by Lucide React
- Font: Roboto from Google Fonts

## 📞 Support

If you encounter any issues or have questions, please:
1. Check the existing issues on GitHub
2. Create a new issue with detailed information
3. Provide steps to reproduce any bugs

---

**Made with ❤️ for better password security**
