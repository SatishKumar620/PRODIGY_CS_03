# Contributing to Password Complexity Checker

Thank you for your interest in contributing to the Password Complexity Checker! This document provides guidelines for contributing to the project.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Making Changes](#making-changes)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Submitting Changes](#submitting-changes)
- [Reporting Issues](#reporting-issues)

## Code of Conduct

This project adheres to a code of conduct that promotes a welcoming and inclusive environment for all contributors. Please be respectful and professional in all interactions.

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally
3. Create a new branch for your feature or bug fix
4. Make your changes
5. Test your changes thoroughly
6. Submit a pull request

## Development Setup

### Prerequisites

- Node.js (version 18 or higher)
- npm (comes with Node.js)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/password-complexity-checker.git
cd password-complexity-checker
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

## Making Changes

### Branch Naming

Use descriptive branch names that indicate the type of change:
- `feature/add-new-validation-rule`
- `fix/password-strength-calculation`
- `docs/update-readme`
- `style/improve-responsive-design`

### Commit Messages

Write clear, concise commit messages:
- Use present tense ("Add feature" not "Added feature")
- Use imperative mood ("Move cursor to..." not "Moves cursor to...")
- Limit the first line to 72 characters or less
- Reference issues and pull requests liberally after the first line

## Coding Standards

### TypeScript

- Use TypeScript for all new code
- Enable strict mode in TypeScript configuration
- Provide proper type annotations
- Use interfaces for object shapes
- Follow existing naming conventions

### React

- Use functional components with hooks
- Follow React best practices
- Use proper prop types
- Implement proper error boundaries where needed
- Use meaningful component names

### Styling

- Use Tailwind CSS for styling
- Follow the existing design system
- Maintain responsive design principles
- Use CSS variables for theming
- Keep styles consistent with the overall design

### File Organization

- Place components in appropriate directories
- Use descriptive file names
- Keep files focused on single responsibilities
- Follow the existing project structure

## Testing

### Manual Testing

Before submitting changes:

1. Test the password strength calculation with various inputs
2. Verify all password requirements work correctly
3. Check responsive design on different screen sizes
4. Test screenshot and download functionality
5. Ensure no console errors or warnings

### Test Cases to Verify

- Password strength calculation accuracy
- All password requirements are properly validated
- UI updates correctly in real-time
- Screenshot generation works properly
- ZIP download includes all necessary files
- Application works on different browsers

## Submitting Changes

### Pull Request Process

1. Update the README.md with details of changes if applicable
2. Update the CHANGELOG.md with your changes
3. Ensure your code follows the project's coding standards
4. Make sure all tests pass
5. Create a pull request with a clear title and description

### Pull Request Template

```
## Description
Brief description of the changes made

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Manual testing completed
- [ ] All existing functionality verified
- [ ] New functionality tested

## Screenshots (if applicable)
Include screenshots or GIFs demonstrating the changes

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex code
- [ ] Documentation updated
- [ ] No breaking changes (or clearly documented)
```

## Reporting Issues

### Bug Reports

When reporting bugs, please include:

1. **Environment**: Browser, OS, Node.js version
2. **Steps to reproduce**: Clear steps to reproduce the issue
3. **Expected behavior**: What should happen
4. **Actual behavior**: What actually happens
5. **Screenshots**: If applicable
6. **Console errors**: Any error messages

### Feature Requests

When requesting features, please include:

1. **Use case**: Why this feature would be valuable
2. **Proposed solution**: How you envision it working
3. **Alternatives**: Other solutions you've considered
4. **Additional context**: Any other relevant information

## Development Guidelines

### Adding New Password Rules

1. Update the `PasswordRequirements` interface
2. Modify the `checkPasswordComplexity` function
3. Add corresponding UI elements
4. Update documentation

### Modifying UI Components

1. Maintain consistency with existing design
2. Ensure accessibility standards
3. Test responsive behavior
4. Update TypeScript types as needed

### Backend Changes

1. Follow RESTful API principles
2. Implement proper error handling
3. Maintain type safety
4. Document API changes

## Getting Help

- Check existing issues and pull requests
- Read the project documentation
- Ask questions in issue comments
- Contact maintainers if needed

## Recognition

Contributors will be recognized in the project documentation and release notes. We appreciate all contributions, no matter how small!

Thank you for contributing to the Password Complexity Checker!