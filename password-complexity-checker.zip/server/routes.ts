import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import puppeteer from "puppeteer";
import archiver from "archiver";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function registerRoutes(app: Express): Promise<Server> {
  // Screenshot endpoint
  app.post("/api/screenshot", async (req, res) => {
    try {
      const browser = await puppeteer.launch({
        headless: true,
        executablePath: '/usr/bin/chromium',
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu',
          '--disable-extensions',
          '--disable-plugins',
          '--disable-images',
          '--disable-javascript'
        ]
      });
      
      const page = await browser.newPage();
      await page.setViewport({ width: 1200, height: 800 });
      
      // Navigate to the application
      await page.goto('http://localhost:5000', {
        waitUntil: 'networkidle2'
      });
      
      // Wait for the page to load completely
      await page.waitForSelector('[data-testid="password-checker"]', { timeout: 5000 })
        .catch(() => {
          // If the test selector doesn't exist, wait for the main content
          return page.waitForSelector('.min-h-screen', { timeout: 5000 });
        });
      
      // Add a sample password to show the functionality
      await page.type('input[type="password"]', 'SecurePass123!');
      await new Promise(resolve => setTimeout(resolve, 1000)); // Wait for animations
      
      const screenshot = await page.screenshot({
        type: 'png',
        fullPage: true
      });
      
      await browser.close();
      
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Content-Disposition', 'attachment; filename="password-checker-screenshot.png"');
      res.send(screenshot);
    } catch (error) {
      console.error('Screenshot error:', error);
      res.status(500).json({ error: 'Failed to capture screenshot' });
    }
  });

  // Download zip endpoint
  app.post("/api/download-zip", async (req, res) => {
    try {
      const projectRoot = path.resolve(__dirname, '..');
      const outputPath = path.join(projectRoot, 'password-complexity-checker.zip');
      
      // Create a file to stream to
      const output = fs.createWriteStream(outputPath);
      const archive = archiver('zip', {
        zlib: { level: 9 } // Set compression level
      });

      // Listen for all archive data to be written
      output.on('close', () => {
        console.log(`Archive created: ${archive.pointer()} total bytes`);
        
        // Send the zip file
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="password-complexity-checker.zip"');
        
        const fileStream = fs.createReadStream(outputPath);
        fileStream.pipe(res);
        
        fileStream.on('end', () => {
          // Clean up the temporary file
          fs.unlinkSync(outputPath);
        });
      });

      archive.on('error', (err) => {
        throw err;
      });

      // Pipe archive data to the file
      archive.pipe(output);

      // Add source files to the archive
      archive.directory(path.join(projectRoot, 'client'), 'client');
      archive.directory(path.join(projectRoot, 'server'), 'server');
      archive.directory(path.join(projectRoot, 'shared'), 'shared');
      
      // Add configuration files
      const configFiles = [
        'package.json',
        'package-lock.json',
        'tsconfig.json',
        'vite.config.ts',
        'tailwind.config.ts',
        'postcss.config.js',
        'components.json',
        'drizzle.config.ts'
      ];
      
      configFiles.forEach(fileName => {
        const filePath = path.join(projectRoot, fileName);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: fileName });
        }
      });
      
      // Add documentation files
      const documentationFiles = [
        'README.md',
        'LICENSE',
        'CHANGELOG.md',
        'CONTRIBUTING.md',
        'SECURITY.md',
        '.gitignore'
      ];
      
      documentationFiles.forEach(fileName => {
        const filePath = path.join(projectRoot, fileName);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: fileName });
          console.log(`Added ${fileName} to archive`);
        } else {
          console.log(`File ${fileName} not found`);
        }
      });

      // Finalize the archive
      archive.finalize();
    } catch (error) {
      console.error('Zip creation error:', error);
      res.status(500).json({ error: 'Failed to create zip file' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
