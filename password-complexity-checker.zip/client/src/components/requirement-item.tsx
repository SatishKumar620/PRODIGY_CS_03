import { Check, X } from "lucide-react";

interface RequirementItemProps {
  met: boolean;
  text: string;
}

export function RequirementItem({ met, text }: RequirementItemProps) {
  return (
    <div className="flex items-center space-x-3 transition-all duration-200">
      <div className="flex-shrink-0">
        {met ? (
          <Check className="w-4 h-4 text-green-500" />
        ) : (
          <X className="w-4 h-4 text-gray-400" />
        )}
      </div>
      <span
        className={`text-sm transition-colors duration-200 ${
          met ? "text-green-600" : "text-gray-500"
        }`}
      >
        {text}
      </span>
    </div>
  );
}
