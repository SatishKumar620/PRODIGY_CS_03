interface PasswordStrengthIndicatorProps {
  strength: number;
  strengthText: string;
  strengthColor: string;
}

export function PasswordStrengthIndicator({
  strength,
  strengthText,
  strengthColor,
}: PasswordStrengthIndicatorProps) {
  const getStrengthBarClass = (strength: number): string => {
    if (strength === 0) return "bg-gray-300";
    if (strength < 50) return "bg-red-500";
    if (strength < 85) return "bg-orange-500";
    return "bg-green-500";
  };

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-gray-700">
          Password Strength
        </span>
        <span className={`text-sm font-medium ${strengthColor}`}>
          {strengthText}
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-300 ${getStrengthBarClass(
            strength
          )}`}
          style={{ width: `${strength}%` }}
        />
      </div>
    </div>
  );
}
