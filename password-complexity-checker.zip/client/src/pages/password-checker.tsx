import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff, Shield, Info, Download, Camera } from "lucide-react";
import { PasswordStrengthIndicator } from "@/components/password-strength-indicator";
import { RequirementItem } from "@/components/requirement-item";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PasswordRequirements {
  length: boolean;
  uppercase: boolean;
  lowercase: boolean;
  number: boolean;
  special: boolean;
  noSpace: boolean;
}

export default function PasswordChecker() {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [requirements, setRequirements] = useState<PasswordRequirements>({
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false,
    noSpace: false,
  });
  const [isGeneratingScreenshot, setIsGeneratingScreenshot] = useState(false);
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const { toast } = useToast();

  const checkPasswordComplexity = (password: string): PasswordRequirements => {
    return {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password),
      noSpace: !/\s/.test(password),
    };
  };

  const calculateStrength = (requirements: PasswordRequirements): number => {
    const metRequirements = Object.values(requirements).filter(Boolean).length;
    const totalRequirements = Object.keys(requirements).length;
    return (metRequirements / totalRequirements) * 100;
  };

  const getStrengthText = (strength: number): string => {
    if (strength === 0) return "Enter a password";
    if (strength < 50) return "Weak";
    if (strength < 85) return "Medium";
    return "Strong";
  };

  const getStrengthColor = (strength: number): string => {
    if (strength === 0) return "text-gray-500";
    if (strength < 50) return "text-red-500";
    if (strength < 85) return "text-orange-500";
    return "text-green-500";
  };

  useEffect(() => {
    const newRequirements = checkPasswordComplexity(password);
    setRequirements(newRequirements);
  }, [password]);

  const handleScreenshot = async () => {
    setIsGeneratingScreenshot(true);
    try {
      const response = await apiRequest("POST", "/api/screenshot", {});
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "password-checker-screenshot.png";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Screenshot captured",
        description: "Screenshot has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to capture screenshot. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingScreenshot(false);
    }
  };

  const handleDownloadZip = async () => {
    setIsGeneratingZip(true);
    try {
      const response = await apiRequest("POST", "/api/download-zip", {});
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "password-complexity-checker.zip";
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download complete",
        description: "Application package has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download package. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const strength = calculateStrength(requirements);

  return (
    <div className="bg-gray-100 min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary text-white rounded-full mb-4">
            <Shield className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-medium text-gray-700 mb-2">
            Password Complexity Checker
          </h1>
          <p className="text-gray-500 text-sm">
            Create a secure password that meets all requirements
          </p>
        </div>

        {/* Main Card */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            {/* Password Input Section */}
            <div className="relative mb-6">
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pr-10 py-4 border-gray-300 focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-200"
                  placeholder=" "
                  autoComplete="new-password"
                />
                <Label
                  className={`absolute left-3 transition-all duration-200 pointer-events-none origin-left ${
                    password
                      ? "top-0 -translate-y-1/2 scale-75 text-primary bg-white px-1"
                      : "top-4 text-gray-500"
                  }`}
                >
                  Enter your password
                </Label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-4 text-gray-500 hover:text-gray-700 focus:outline-none"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* Strength Indicator */}
            <PasswordStrengthIndicator
              strength={strength}
              strengthText={getStrengthText(strength)}
              strengthColor={getStrengthColor(strength)}
            />

            {/* Requirements Checklist */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-700 mb-3">
                Requirements
              </h3>

              <RequirementItem
                met={requirements.length}
                text="At least 8 characters long"
              />
              <RequirementItem
                met={requirements.uppercase}
                text="Contains uppercase letter (A-Z)"
              />
              <RequirementItem
                met={requirements.lowercase}
                text="Contains lowercase letter (a-z)"
              />
              <RequirementItem
                met={requirements.number}
                text="Contains number (0-9)"
              />
              <RequirementItem
                met={requirements.special}
                text="Contains special character (!@#$%^&*)"
              />
              <RequirementItem
                met={requirements.noSpace}
                text="No spaces allowed"
              />
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <Button
            onClick={handleScreenshot}
            disabled={isGeneratingScreenshot}
            className="flex-1 bg-primary hover:bg-primary/90"
          >
            {isGeneratingScreenshot ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Capturing...
              </>
            ) : (
              <>
                <Camera className="w-4 h-4 mr-2" />
                Screenshot
              </>
            )}
          </Button>
          <Button
            onClick={handleDownloadZip}
            disabled={isGeneratingZip}
            className="flex-1 bg-green-600 hover:bg-green-700"
          >
            {isGeneratingZip ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Packaging...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Download Zip
              </>
            )}
          </Button>
        </div>

        {/* Additional Info */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Info className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-blue-900 mb-1">
                  Security Tips
                </h4>
                <p className="text-sm text-blue-700">
                  Use a unique password for each account and consider using a
                  password manager for better security.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
